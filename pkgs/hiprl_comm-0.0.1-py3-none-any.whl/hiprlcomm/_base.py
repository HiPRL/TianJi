from abc import ABCMeta, abstractmethod

import os
import threading



class CommBase(metaclass=ABCMeta):


    @abstractmethod
    def send(self, *args, **kwargs):
        """
        comm base send api.
        """
        raise NotImplementedError()
    
    @abstractmethod
    def recv(self, *args, **kwargs):
        """
        comm base recv api.
        """
        raise NotImplementedError()


class SingletonType(type):
    _instance = None
    _instance_lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = super().__call__(*args, **kwargs)
        return cls._instance


class ProcessSingleton(type):
    _process_pids = {}
    _process_instance_lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        pids = ProcessSingleton._process_pids
        pid = cls._get_pid()
        if pid not in pids:
            with ProcessSingleton._process_instance_lock:
                if pid not in pids:
                    pids[pid] = {}
                    pids[pid][cls] = super().__call__(*args, **kwargs)
        
        current_pid = pids[pid]
        if cls not in current_pid:
            with ProcessSingleton._process_instance_lock:
                if cls not in current_pid:
                    current_pid[cls] = super().__call__(*args, **kwargs)
        return current_pid[cls]

    @staticmethod
    def _get_pid():
        return os.getpid()