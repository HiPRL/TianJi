from ._base import CommBase

import os
import pickle



class CommDirect(CommBase):
    """
    this module will used to be comm for loacl file.
    """
    def __init__(self, comm, base_dir='.'):
        self.comm = comm
        self.base_dir = base_dir

        self.model_dir = os.path.join(base_dir, 'model')   # local save model params
        self.actor_dir = os.path.join(base_dir, 'actor')   # local save sample data
        self.buffer_dir = os.path.join(base_dir, 'buffer') # local save sample data
        for item in [self.base_dir, self.model_dir, self.actor_dir, self.buffer_dir]:
            if not os.path.exists(item):
                os.makedirs(item)

    def rank(self):
        return self.comm.Get_rank()

    def send(self, data, dest):
        with open(dest, 'wb') as f:
            pickle.dump(data, f)
    
    def recv(self, file_name):
        with open(file_name, 'rb') as f:
            data = pickle.load(f)
        return data

    def check_create(self, file_name):
        os.mknod(file_name)

    def check_exists(self, file_name):
        return os.path.exists(file_name)
    
    def clean_files(self, file_name):
        files = os.listdir(file_name)
        for f in files:
            os.remove(os.path.join(file_name, f))