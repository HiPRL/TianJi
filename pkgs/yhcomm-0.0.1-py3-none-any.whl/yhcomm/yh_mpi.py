from ._base import CommBase, SingletonType

import pickle
import functools
from collections import deque
from mpi4py import MPI



class CommMpi(CommBase):
    """
    mpi comm api.
    """
    def __init__(self, comm, buff_size=2**25 * 32, name=None, *args, **kwargs):
        self._name = f"comm_{name}" if name is not None else "comm"
        self.comm = comm
        self.buff_size = buff_size

        # ask_recv api var
        self.req = None
        self.run_flag = True
        self.ask_index = 0
        self.ask_pool = deque([], maxlen=3)
    
    @property
    def name(self):
        return self._name

    @property
    def rank(self):
        return self.comm.Get_rank()

    @property
    def rank_size(self):
        return self.comm.Get_size()

    @property
    def node_name(self):
        return MPI.Get_processor_name

    def distinguish_comm(self, comm=None):
        cm = comm if comm is not None else self.comm
        return MPI.COMM_NULL != cm

    def convert_comm_cls(self, comm_dict, comm_cls, comm_registry_func, comm_registry_cfg):
        assert isinstance(comm_dict, dict)
        for key, cm in comm_dict.items():
            if self.distinguish_comm(cm):
                _cm = comm_cls(comm=cm, name=f"{cm.name}_{key}")
                comm_registry_func(_cm, comm_registry_cfg)
                comm_dict[key] = _cm

    def send(self, data, mpi_dest, mpi_tag=1, blocking=True, cache=False):
        if blocking:
            if cache:
                self.comm.Send(data, dest=mpi_dest, tag=mpi_tag)
            return self.comm.send(data, dest=mpi_dest, tag=mpi_tag)
        else:
            if cache:
                return self.comm.Isend(data, dest=mpi_dest, tag=mpi_tag)
            return self.comm.isend(data, dest=mpi_dest, tag=mpi_tag)

    def recv(self, mpi_source, mpi_tag=1, blocking=True, cache=False):
        if blocking:
            if cache:
                self.comm.Recv(self.buff_size, source=mpi_source, tag=mpi_tag)
            else:
                req = self.comm.recv(self.buff_size, source=mpi_source, tag=mpi_tag)
        else:
            if cache:
                req = self.comm.Irecv(self.buff_size, source=mpi_source, tag=mpi_tag)
            else:
                req = self.comm.irecv(self.buff_size, source=mpi_source, tag=mpi_tag)
        return req
    
    def rsend(self, data, mpi_dest, mpi_tag=1):
        return self.comm.Rsend(pickle.dumps(data), dest=mpi_dest, tag=mpi_tag)

    def rrecv(self, mpi_source, mpi_tag=1):
        self.comm.Recv(self.buff_size, source=mpi_source, tag=mpi_tag)
        return pickle.loads(self.buff_size)

    def ask_recv(self, mpi_source, mpi_tag=1):
        if self.run_flag:
            self.req = self.recv(mpi_source, mpi_tag=mpi_tag, blocking=False)
            self.run_flag = False
        else:
            ret = self.req.test()
            self.run_flag = ret[0]
            if self.run_flag:
                return ret[1]

    def ask_wait(cls, mpi_source, mpi_tag=1, return_size=1):
        if return_size < 1:
            return_size = 1
        elif return_size > len(cls.ask_pool):
            return_size = len(cls.ask_pool)
        else:
            return_size = return_size

        while True:
            data = cls.ask_recv(mpi_source, mpi_tag=mpi_tag)
            if data:
                cls.ask_pool.append({cls.ask_index: data})
                cls.ask_index += 1
                if len(cls.ask_pool) >= return_size:
                    break
        return cls.ask_pool.popleft().values()

    def check(self, mpi_req):
        if hasattr(mpi_req, "test"):
            return mpi_req.test()
    
    def wait(self, mpi_req):
        if hasattr(mpi_req, "wait"):
            mpi_req.wait()


class DrlMpi(CommMpi):
    def __init__(self, comm=None, *args, **kwargs):
        self.comm = MPI.COMM_WORLD if comm is None else comm
        self._learner_rank = []
        self._actor_rank = []
        self._buffer_rank = []
        super().__init__(self.comm, *args, **kwargs)
    
    @property
    def actor_rank(self):
        return self._actor_rank

    @property
    def learner_rank(self):
        return self._learner_rank

    @property
    def buffer_rank(self):
        return self._buffer_rank

    @property
    def is_master(self):
        return self.rank == 0

    @property
    def is_actor(self):
        return self.rank in self._actor_rank

    @property
    def is_learner(self):
        return self.rank in self._learner_rank

    @property
    def is_buffer(self):
        return self.rank in self._buffer_rank

    def dispath_process_func(self, role=None):
        Role = {
            "MASTER" : self.is_master,
            "LEARNER" : self.is_learner,
            "ACTOR" : self.is_actor,
            "BUFFER" : self.is_buffer
        }

        def call(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                if role:
                    role_status = Role.get(role.upper(), "NONE")
                    assert role_status != "NONE", f"role must be a MASTER、LEARNER、ACTOR or BUFFER, but got {role_status}"
                    if role_status:
                        return func(*args, **kwargs)
                else:
                    return func(*args, **kwargs)

            return wrapper
        return call

    def registry_rank(self, rank_ids):
        if isinstance(rank_ids, dict):
            self._learner_rank.extend(rank_ids["learner"])
            self._actor_rank.extend(rank_ids["actor"])
            self._buffer_rank.extend(rank_ids["buffer"])
        else:
            AttributeError(f"rank registry type must be dict and the child attribute is learner、actor、buffer, but got {type(rank_ids)}")


class MasterSlaveWithMPI(CommMpi):
    def __init__(self, comm=None, *args, **kwargs):
        super(MasterSlaveWithMPI, self).__init__(comm, *args, **kwargs)
        self._master_rank = None
        self._slave_ranks = []
    
    @property
    def is_master_learner(self):
        return self.rank == self._master_rank

    @property
    def root_learner_rank(self):
        return self._master_rank

    @property
    def child_learner_rank(self):
        return self._slave_ranks

    def registry_rank(self, rank_ids):
        if isinstance(rank_ids, dict):
            self._master_rank = rank_ids["master_learner"]
            self._slave_ranks.extend(rank_ids["slave_learner"])
        else:
            AttributeError(f"rank registry type must be dict and the child attribute is master_learner、slave_learner, but got {type(rank_ids)}")